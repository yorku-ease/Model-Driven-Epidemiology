<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='TARGET_DEFINITION:resource:/org.compartmental.targetplatform/compartment.target' timestamp='1762403171484'>
  <properties size='12'>
    <property name='org.eclipse.pde.core.all_environments' value='false'/>
    <property name='org.eclipse.equinox.p2.cache' value='/home/fatemeh/Documents/york/Code/Model/Model-Driven-Epidemiology/runtime-EclipseApplication/.metadata/.plugins/org.eclipse.pde.core/.bundle_pool'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.pde.core.sequence' value='0'/>
    <property name='org.eclipse.pde.core.includeConfigure' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.ws=gtk,osgi.os=linux,osgi.arch=x86_64'/>
    <property name='org.eclipse.pde.core.provision_mode' value='planner'/>
    <property name='org.eclipse.pde.core.autoIncludeSource' value='true'/>
    <property name='org.eclipse.pde.core.followRepositoryReferences' value='true'/>
    <property name='org.eclipse.pde.core.repositories' value='https%3A%2F%2Fdownload.eclipse.org%2Freleases%2F2024-12%2F,https%3A%2F%2Fdownload.eclipse.org%2Fsirius%2Fupdates%2Freleases%2F7.4.7%2F2023-03%2F'/>
    <property name='org.eclipse.equinox.p2.nl' value='en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/fatemeh/Documents/york/Code/Model/Model-Driven-Epidemiology/runtime-EclipseApplication/.metadata/.plugins/org.eclipse.pde.core/.install_folders/1762403171478'/>
  </properties>
</profile>
